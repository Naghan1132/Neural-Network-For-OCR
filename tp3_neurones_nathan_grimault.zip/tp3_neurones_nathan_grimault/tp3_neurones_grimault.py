import numpy as np
import string

exemple_a_reconnaitreA =[ [False,  True,  True,  True,  False],  # { A } OK
                           [True,  False, False, False, True],
                           [True,  True,  True,  True,  False],
                           [True,  False, False, False,  True],
                           [True,  False, False, False, True] ]

exemple_a_reconnaitreB = [ [False,  True,  True,  True,  False],  # { B } OK
                           [True,  False, False, False, True],
                           [True,  True,  True,  True,  False],
                           [True,  False, False, False, True],
                           [True,  True,  True,  True,  False] ]

exemple_a_reconnaitreC = [ [True, True,  True,  True,  True],   # { C } OK
                           [True,  False, False, False, False],
                           [True,  False, False, False, False],
                           [True,  False, False, False, False],
                           [False, True,  True,  True,  True] ]


exemple_a_reconnaitreD = [ [False,  False,  True,  True,  False],  # { D } OK
                           [True,  False, False, False, True],
                           [True,  False, False, False, True],
                           [True,  False, False, False, True],
                           [True,  True,  True,  True,  False] ]


exemple_a_reconnaitreE = [ [True,  True,  True,  True,  True],   # { E } OK
                         [True,  False, False, False, False],
                         [True,  True,  True,  True, False],
                         [True,  False, False, False, False],
                         [True,  True,  True,  True,  True] ]


exemple_a_reconnaitreF = [ [True,  True,  True,  True,  True],   # { F } OK
                           [True,  False, False, False, False],
                           [True,  True,  True,  False, False],
                           [True,  False, False, False, False],
                           [True,  True, False, False, False] ]

exemple_a_reconnaitreG = [ [True,  True,  True,  True,  True],   # { G } OK
                           [True,  False, True, False, False],
                           [True,  False, False, False, False],
                           [True,  False, False, False, True],
                           [True,  True,  True,  True,  True] ]

exemple_a_reconnaitreH = [ [True,  False, False, False, True],   # { H } OK
                           [True,  False, False, False, True],
                           [True,  True,  True,  True,  True],
                           [True,  True, False, False, True],
                           [True,  False, False, False, True] ]

exemple_a_reconnaitreI = [ [False, False, True,  False, False],  # { I } KO reconnait T
                           [False, True, True,  False, False],
                           [False, False, True,  False, False],
                           [False, False, True,  False, False],
                           [False, False, True,  False, False] ]

exemple_a_reconnaitreJ = [ [True, False, True,  True,  True],   # { J } # OK
                           [False, False, False, True,  False],
                           [False, False, False, True,  False],
                           [False, False, False, True,  False],
                           [True,  True,  True,  True,  False] ]

exemple_a_reconnaitreK = [ [True,  False, False, False, True],   # { K } OK
                           [True,  False, False, True,  False],
                           [True,  True,  True,  True, False],
                           [True,  False, False, True,  False],
                           [True,  False, False, False, True] ]

exemple_a_reconnaitreL = [ [False,  False, False, False, False],  # { L } OK
                           [False,  False, False, False, False],
                           [True,  False, False, False, False],
                           [True,  False, False, False, False],
                           [True,  True,  True,  True,  True] ]

exemple_a_reconnaitreM = [ [True,  True,  True, True,  True],   # { M } OK
                           [True,  False, True,  False, True], 
                           [True,  False, False, False, True],
                           [True,  False, False, False, True],
                           [True,  False, False, False, True] ]



exemple_a_reconnaitreN = [ [True,  True, False, False, True],   # { N } OK
                           [True,  True,  False, False, True],
                           [True,  False, True,  False, True],
                           [True,  False, False, True,  True],
                           [True,  False, False, False, True] ]

exemple_a_reconnaitreO = [ [False, False,  True,  True,  False],  # { O } OK
                           [True,  False, False, False, True],
                           [True,  False, False, False, True],
                           [True,  False, False, False, True],
                           [False, True,  True,  True,  False] ]


exemple_a_reconnaitreP = [ [True,  False,  True,  True,  False],  # { P } OK
                           [True,  False, False, False, True],
                           [True,  True,  True,  True,  False],
                           [True,  False, False, False, False],
                           [True,  False, False, False, False] ]

exemple_a_reconnaitreQ = [ [True,  True,  True,  False,  False],   # { Q } OK
                           [True,  False, False, False, False],
                           [True,  False, False, False, True],
                           [True,  False, False, True,  True],
                           [True,  True,  True,  True,  True] ]


exemple_a_reconnaitreR =[ [True,  True,  True,  True,  True],  # { R } OK
                          [True,  False, False, False, True],
                          [True,  True,  True,  True,  False],
                          [True,  False, False, True,  False],
                          [True,  False, False, False, True] ]



exemple_a_reconnaitreS = [ [False, False,  True,  True,  True],   # { S } OK
                           [True,  False, False, False, False],
                           [False, True,  True,  True,  False],
                           [False, False, False, False, True],
                           [True,  True,  True,  True,  False] ]

exemple_a_reconnaitreT = [ [False,  True,  True,  True,  True],   # { T } OK
                           [False, False, True,  True, False],
                           [False, False, True,  False, False],
                           [False, False, True,  False, False],
                           [False, False, True,  False, False] ]

exemple_a_reconnaitreU = [ [False,  False, False, False, True],   # { U } OK
                           [True,  False, False, False, True],
                           [True,  False, False, False, True],
                           [False,  False, False, False, True],
                           [False, True,  True,  True,  False] ]

exemple_a_reconnaitreV = [ [True,  False, False, False, True],   # { V } OK
                           [True,  False, False, False, True],
                           [True,  False, False, False, True],
                           [True, True,  False, True, False],
                           [False, False, True,  False, False] ]

exemple_a_reconnaitreW = [ [True,  False, False, False, True],   # { W } OK
                           [True,  False, False, False, True],
                           [True,  False, False, False, True],
                           [True,  False, True,  False, False],
                           [False, True,  False, True,  False] ]

exemple_a_reconnaitreX = [ [True,  False, False, False, True],   # { X } OK
                           [False, True,  False, False,  False],
                           [False, False, True,  False, False],
                           [False, True,  False, True,  False],
                           [True,  False, False, False, True] ]

exemple_a_reconnaitreY = [ [True,  False, False, False, True],   # { Y } OK
                           [False, True,  False, True,  True],
                           [False, False, True,  False, False],
                           [False, False, True,  False, False],
                           [False, False, True,  False, False] ]

exemple_a_reconnaitreZ = [ [True,  True,  True,  True,  True],   # { Z } OK
                           [True, False, False, True,  False],
                           [False, False, True,  False, False],
                           [False, True,  False, False, False],
                           [True,  True,  True,  True,  True] ]

alphabet = \
[ [ [False, True,  True,  True,  False],  # { A }
     [True,  False, False, False, True],
     [True,  True,  True,  True,  True],
     [True,  False, False, False, True],
     [True,  False, False, False, True] ],
   [ [True,  True,  True,  True,  False],  # { B }
     [True,  False, False, False, True],
     [True,  True,  True,  True,  False],
     [True,  False, False, False, True],
     [True,  True,  True,  True,  False] ],
   [ [False, True,  True,  True,  True],   # { C }
     [True,  False, False, False, False],
     [True,  False, False, False, False],
     [True,  False, False, False, False],
     [False, True,  True,  True,  True] ],
   [ [True,  True,  True,  True,  False],  # { D }
     [True,  False, False, False, True],
     [True,  False, False, False, True],
     [True,  False, False, False, True],
     [True,  True,  True,  True,  False] ],
   [ [True,  True,  True,  True,  True],   # { E }
     [True,  False, False, False, False],
     [True,  True,  True,  False, False],
     [True,  False, False, False, False],
     [True,  True,  True,  True,  True] ],
   [ [True,  True,  True,  True,  True],   # { F }
     [True,  False, False, False, False],
     [True,  True,  True,  False, False],
     [True,  False, False, False, False],
     [True,  False, False, False, False] ],
   [ [True,  True,  True,  True,  True],   # { G }
     [True,  False, False, False, False],
     [True,  False, False, False, False],
     [True,  False, False, False, True],
     [True,  True,  True,  True,  True] ],
   [ [True,  False, False, False, True],   # { H }
     [True,  False, False, False, True],
     [True,  True,  True,  True,  True],
     [True,  False, False, False, True],
     [True,  False, False, False, True] ],
   [ [False, False, True,  False, False],  # { I }
     [False, False, True,  False, False],
     [False, False, True,  False, False],
     [False, False, True,  False, False],
     [False, False, True,  False, False] ],
   [ [False, False, True,  True,  True],   # { J }
     [False, False, False, True,  False],
     [False, False, False, True,  False],
     [False, False, False, True,  False],
     [True,  True,  True,  True,  False] ],
   [ [True,  False, False, False, True],   # { K }
     [True,  False, False, True,  False],
     [True,  True,  True,  False, False],
     [True,  False, False, True,  False],
     [True,  False, False, False, True] ],
   [ [True,  False, False, False, False],  # { L }
     [True,  False, False, False, False],
     [True,  False, False, False, False],
     [True,  False, False, False, False],
     [True,  True,  True,  True,  True] ],
   [ [True,  True,  False, True,  True],   # { M }
     [True,  False, True,  False, True],
     [True,  False, False, False, True],
     [True,  False, False, False, True],
     [True,  False, False, False, True] ],
   [ [True,  False, False, False, True],   # { N }
     [True,  True,  False, False, True],
     [True,  False, True,  False, True],
     [True,  False, False, True,  True],
     [True,  False, False, False, True] ],
   [ [False, True,  True,  True,  False],  # { O }
     [True,  False, False, False, True],
     [True,  False, False, False, True],
     [True,  False, False, False, True],
     [False, True,  True,  True,  False] ],
   [ [True,  True,  True,  True,  False],  # { P }
     [True,  False, False, False, True],
     [True,  True,  True,  True,  False],
     [True,  False, False, False, False],
     [True,  False, False, False, False] ],
   [ [True,  True,  True,  True,  True],   # { Q }
     [True,  False, False, False, True],
     [True,  False, False, False, True],
     [True,  False, False, True,  True],
     [True,  True,  True,  True,  True] ],
   [ [True,  True,  True,  True,  False],  # { R }
     [True,  False, False, False, True],
     [True,  True,  True,  True,  False],
     [True,  False, False, True,  False],
     [True,  False, False, False, True] ],
   [ [False, True,  True,  True,  True],   # { S }
     [True,  False, False, False, False],
     [False, True,  True,  True,  False],
     [False, False, False, False, True],
     [True,  True,  True,  True,  False] ],
   [ [True,  True,  True,  True,  True],   # { T }
     [False, False, True,  False, False],
     [False, False, True,  False, False],
     [False, False, True,  False, False],
     [False, False, True,  False, False] ],
   [ [True,  False, False, False, True],   # { U }
     [True,  False, False, False, True],
     [True,  False, False, False, True],
     [True,  False, False, False, True],
     [False, True,  True,  True,  False] ],
   [ [True,  False, False, False, True],   # { V }
     [True,  False, False, False, True],
     [True,  False, False, False, True],
     [False, True,  False, True,  False],
     [False, False, True,  False, False] ],
   [ [True,  False, False, False, True],   # { W }
     [True,  False, False, False, True],
     [True,  False, False, False, True],
     [True,  False, True,  False, True],
     [False, True,  False, True,  False] ],
   [ [True,  False, False, False, True],   # { X }
     [False, True,  False, True,  False],
     [False, False, True,  False, False],
     [False, True,  False, True,  False],
     [True,  False, False, False, True] ],
   [ [True,  False, False, False, True],   # { Y }
     [False, True,  False, True,  False],
     [False, False, True,  False, False],
     [False, False, True,  False, False],
     [False, False, True,  False, False] ],
   [ [True,  True,  True,  True,  True],   # { Z }
     [False, False, False, True,  False],
     [False, False, True,  False, False],
     [False, True,  False, False, False],
     [True,  True,  True,  True,  True] ] ]

alphabetString = list(string.ascii_uppercase)

def affichage(lettre,N):
    box = chr(0x2588) + chr(0x2588)
    for i in range(N):
        for j in range(N):
            if lettre[i][j]:
                print (box, end="")
            else :
                print ("  ", end="")
        print ("")
    print ("")
 
# INITIALISATION :

f_activation = lambda x: 0 if x < 0 else 1

N = 5 # nombre de lignes (et de colonnes) d'une forme
N_cell = N*N

# seuils des cellules du réseau (réels)
seuils = [0.0 for _ in range(N_cell)]
# poids des connexions du réseau (réels)
poids = [[0.5 for _ in range(N_cell)] for _ in range(N_cell)]

def symetriePoids():
    for i in range (25):# symétrie en 0 des poids OK
        poids[i][i] = 0
        
symetriePoids()

def matrice_a_liste(matrice):
    #transforme une matrice en liste []
    etats = []
    for i in range(5):
        for j in range(5):
            etats.append(matrice[i][j])
    return etats

epsilon = 0.2

nbIterationsGlobale = 0
saveNbErreur = []

cptAlphabet = 0
# Apprentissage de l'alphabet,
while True: # on arrête pas tant que qu'il y a encore des erreurs sur tout l'apprentissage
    sommeGlobalErreur = 0
    cptAlpha = 0
    for lettre in alphabet:
        etats = matrice_a_liste(lettre)
        sommeErreurLettre = 0
        #print("Nouvelle lettre apprentissage => ",alphabetString[cptAlpha])
        nbIterations = 0
        while True:
            nbErreur = 0
            for cellule in range (25):
                somme = 0
                cptActif = 0
                for i in range (25):
                    if etats[i]:
                        cptActif += 1
                        somme += poids[cellule][i] # wi*xi (somme des wi car xi = 1 toujours)
                somme -= seuils[cellule] #la somme des (wi) - teta
                if f_activation(somme) != etats[cellule]:#si l'activation ne respecte pas la forme apprise on change
                    nbErreur += 1
                    sommeGlobalErreur += 1
                    if somme < 0: #(désactivé alors qu'on la veut activer)
                        delta = (somme-epsilon)/(cptActif+1) #ajouter ça à tout les poids des etats actif et au seuil
                        seuils[cellule] += delta # OK         
                        cpt = 0
                        for poid in poids[cellule]:
                            if etats[cpt]: # modifie que les poids actif
                                poids[cellule][cpt] -= delta
                            cpt+=1
                        symetriePoids()
                    else: #(activé alors qu'on la veut désactiver)
                        delta = (somme+epsilon)/(cptActif+1)
                        seuils[cellule] += delta
                        cpt = 0
                        for poid in poids[cellule]:
                            if etats[cpt]: # modifie que les poids actif
                                poids[cellule][cpt] -= delta
                            cpt+=1
                        symetriePoids()
                else:
                    #print("bonne activation")
                    pass
            nbIterations += 1
            sommeErreurLettre += nbErreur
            if nbErreur == 0:
                #print("(",alphabetString[cptAlpha],") ETAT STABLE => ",nbIterations," itérations (au total) finies avec ",sommeErreurLettre," erreurs au total \n")
                cptAlpha+=1
                break # alors toute les cellules de la lettre stables
            else:
                # encore des erreurs => on re-boucle sur la même lettre
                #print("itération n° ",nbIterations," finie avec ",nbErreur," erreurs \n")
                pass
    cptAlphabet +=1
    saveNbErreur.append(sommeGlobalErreur)
    print("total erreurs = ",sommeGlobalErreur)
    nbIterationsGlobale += 1
    if sommeGlobalErreur == 0:
        print("\n APPRENTISSAGE TERMINÉ : TOUTES LES LETTRES SONT STABLES SANS ERREURS")
        print("on a parcouru ",cptAlphabet," fois l'alphabet durant l'apprentissage\n")
        break #aucune erreurs sur tout l'alphabet, aucun poids n'as eu besoin de modification, c'est tout bon !
    else:
        pass# encore des erreurs sur une ou plusieurs lettres => on re-boucle sur l'alphabet entier
        
 
# TESTS RECONNAISSANCE : 

def reconnaissance(exemple):
    # print("ACTIVATION AVEC LES BONS POIDS/SEUILS : ")
    # Une fois qu'on a fait apprendre l'algo on active notre forme a reconnaitre 
    # avec les poids et seuil trouvé => on devrait avoir la bonne forme
    etats = []
    for i in range(5):
        for j in range(5):
            etats.append(exemple[i][j]) # on les passe en ligne OK
    
    for cellule in range (25):
        somme = 0
        for i in range (25):
            if etats[i]:
                somme += poids[cellule][i]
        somme -= seuils[cellule]
        etats[cellule] = f_activation(somme)

    formeFinale = [ [etats[0],etats[1],etats[2],etats[3],etats[4]],
                    [etats[5],etats[6],etats[7],etats[8],etats[9]],
                    [etats[10],etats[11],etats[12],etats[13],etats[14]],
                    [etats[15],etats[16],etats[17],etats[18],etats[19]],
                    [etats[20],etats[21],etats[22],etats[23],etats[24]] ]  # on repasse en 5*5 pour l'afficher
    return formeFinale
    



liste_a_reconnaitre = [exemple_a_reconnaitreA,exemple_a_reconnaitreB,exemple_a_reconnaitreC,
                       exemple_a_reconnaitreD,exemple_a_reconnaitreE,exemple_a_reconnaitreF,
                      exemple_a_reconnaitreG,exemple_a_reconnaitreH,exemple_a_reconnaitreI,
                      exemple_a_reconnaitreJ,exemple_a_reconnaitreK,exemple_a_reconnaitreL,
                      exemple_a_reconnaitreM,exemple_a_reconnaitreN,exemple_a_reconnaitreO,
                      exemple_a_reconnaitreP,exemple_a_reconnaitreQ,exemple_a_reconnaitreR,
                      exemple_a_reconnaitreS,exemple_a_reconnaitreT,exemple_a_reconnaitreU,
                      exemple_a_reconnaitreV,exemple_a_reconnaitreW,exemple_a_reconnaitreX,
                      exemple_a_reconnaitreY,exemple_a_reconnaitreZ]



# Graphique :

cptAlpha = 0
for lettre_a_reconnaitre in liste_a_reconnaitre:
    print("forme à reconnaitre : ")
    affichage(lettre_a_reconnaitre,N)
    reconnue = reconnaissance(lettre_a_reconnaitre)
    print("forme stable : ")
    affichage(reconnue,N)
    if reconnue not in alphabet:
        print("lettre pas reconnue")
    else:
        index = alphabet.index(reconnue)
        print("forme reconnue : ",alphabetString[index])
    print("\n_________\n")
    cptAlpha +=1
